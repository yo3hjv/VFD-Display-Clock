SEETRON VFD CONFIGURATION UTILITY, V1.1

This program configures a Seetron VFD-220 or -420 serial display. 
Extract and run the program, pick your options, and click Send 
to download the configuration. 

This assumes that the display is properly connected to the PC and 
to 5Vdc power, that the comm port and baud rate selected are 
correct, and that switch (1) on the VFD interface board is in the 
ON position to enable Configuration Mode. (When the VFD powers up 
w/switch (1) ON, it displays a "Config Mode" message.)

When you are done with the software, you may just delete it from 
your drive; it makes no changes to the system or registry. It is 
compatible with and has been tested on all versions of Windows
from '95 to Win7. 

For more information, please see: 

http://www.seetron.com/vfdx20config.html

Revision History
v1.1, 29 Oct 2012: Added support for com port numbers 9-99. 